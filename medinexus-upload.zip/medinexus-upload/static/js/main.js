/* MediNexus — Main JavaScript */

// Smooth scroll for anchor links
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        const target = document.querySelector(this.getAttribute('href'));
        if (target) target.scrollIntoView({ behavior: 'smooth' });
    });
});

// Intersection Observer for animate-in elements
const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.style.opacity = '1';
            entry.target.style.transform = 'translateY(0)';
        }
    });
}, { threshold: 0.1 });

document.querySelectorAll('.animate-in').forEach(el => {
    el.style.opacity = '0';
    el.style.transform = 'translateY(20px)';
    el.style.transition = 'all 0.6s ease';
    observer.observe(el);
});

// Counter animation for stat numbers
function animateCounters() {
    document.querySelectorAll('.stat-number, .stat-value').forEach(counter => {
        const text = counter.textContent.trim();
        const match = text.match(/^(\d+)/);
        if (!match) return;
        
        const target = parseInt(match[1]);
        const suffix = text.replace(match[1], '');
        if (target === 0 || counter.dataset.animated) return;
        
        counter.dataset.animated = 'true';
        let current = 0;
        const increment = Math.max(1, Math.ceil(target / 40));
        const timer = setInterval(() => {
            current += increment;
            if (current >= target) {
                current = target;
                clearInterval(timer);
            }
            counter.textContent = current + suffix;
        }, 30);
    });
}

// Run counter animation when hero section is visible
const heroObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            animateCounters();
            heroObserver.unobserve(entry.target);
        }
    });
}, { threshold: 0.3 });

const heroSection = document.querySelector('.hero-stats');
if (heroSection) heroObserver.observe(heroSection);

// Tooltip helper
document.querySelectorAll('[data-tooltip]').forEach(el => {
    el.style.position = 'relative';
    el.addEventListener('mouseenter', function() {
        const tip = document.createElement('div');
        tip.className = 'tooltip-popup';
        tip.textContent = this.dataset.tooltip;
        tip.style.cssText = 'position:absolute;bottom:calc(100% + 8px);left:50%;transform:translateX(-50%);background:#333;color:#fff;padding:4px 10px;border-radius:6px;font-size:12px;white-space:nowrap;z-index:999;pointer-events:none;';
        this.appendChild(tip);
    });
    el.addEventListener('mouseleave', function() {
        const tip = this.querySelector('.tooltip-popup');
        if (tip) tip.remove();
    });
});
