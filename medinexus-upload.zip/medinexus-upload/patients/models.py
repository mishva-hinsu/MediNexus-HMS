from django.db import models
from django.conf import settings
from django.utils import timezone


class TimeSlot(models.Model):
    """Available appointment time slots."""
    time = models.CharField(max_length=20)
    period = models.CharField(max_length=10, choices=[
        ('morning', 'Morning'),
        ('afternoon', 'Afternoon'),
        ('evening', 'Evening'),
    ], default='morning')

    class Meta:
        ordering = ['id']

    def __str__(self):
        return self.time


class Appointment(models.Model):
    """Patient appointment with doctor."""
    STATUS_CHOICES = [
        ('pending', 'Pending'),
        ('confirmed', 'Confirmed'),
        ('completed', 'Completed'),
        ('cancelled', 'Cancelled'),
        ('no_show', 'No Show'),
    ]

    PRIORITY_CHOICES = [
        ('low', 'Low'),
        ('normal', 'Normal'),
        ('high', 'High'),
        ('urgent', 'Urgent'),
    ]

    patient = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE,
                                 related_name='patient_appointments')
    doctor = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE,
                                related_name='doctor_appointments')
    date = models.DateField()
    time_slot = models.ForeignKey(TimeSlot, on_delete=models.SET_NULL,
                                   null=True, blank=True)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES,
                               default='pending')
    priority = models.CharField(max_length=10, choices=PRIORITY_CHOICES,
                                 default='normal')
    symptoms = models.TextField(blank=True, help_text='Describe your symptoms')
    notes = models.TextField(blank=True, help_text='Additional notes')
    diagnosis = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['-date', '-created_at']

    def __str__(self):
        return f"{self.patient.full_name} → Dr. {self.doctor.full_name} on {self.date}"

    @property
    def is_past(self):
        return self.date < timezone.now().date()

    @property
    def is_today(self):
        return self.date == timezone.now().date()

    @property
    def status_color(self):
        colors = {
            'pending': 'warning',
            'confirmed': 'info',
            'completed': 'success',
            'cancelled': 'danger',
            'no_show': 'secondary',
        }
        return colors.get(self.status, 'secondary')


class Prescription(models.Model):
    """Prescription linked to an appointment."""
    appointment = models.OneToOneField(Appointment, on_delete=models.CASCADE,
                                        related_name='prescription')
    doctor = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE,
                                related_name='prescriptions_given')
    patient = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE,
                                 related_name='prescriptions_received')
    medications = models.TextField(help_text='List of medications and dosages')
    instructions = models.TextField(blank=True)
    follow_up_date = models.DateField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Rx for {self.patient.full_name} by Dr. {self.doctor.full_name}"


class MedicalRecord(models.Model):
    """Patient medical record entry."""
    patient = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE,
                                 related_name='medical_records')
    doctor = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE,
                                related_name='records_created')
    appointment = models.ForeignKey(Appointment, on_delete=models.SET_NULL,
                                     null=True, blank=True)
    title = models.CharField(max_length=255)
    description = models.TextField()
    record_type = models.CharField(max_length=50, choices=[
        ('diagnosis', 'Diagnosis'),
        ('lab_result', 'Lab Result'),
        ('imaging', 'Imaging'),
        ('procedure', 'Procedure'),
        ('note', 'Clinical Note'),
    ], default='note')
    attachment = models.FileField(upload_to='medical_records/', blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-created_at']

    def __str__(self):
        return f"{self.title} - {self.patient.full_name}"
