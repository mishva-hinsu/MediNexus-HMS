from django import forms
from .models import Appointment, Prescription, MedicalRecord, TimeSlot
from users.models import User, Specialty


class AppointmentBookingForm(forms.ModelForm):
    """Form for patients to book appointments."""
    specialty = forms.ModelChoiceField(
        queryset=Specialty.objects.all(),
        required=False,
        widget=forms.Select(attrs={'class': 'form-input', 'id': 'specialty-select'})
    )
    doctor = forms.ModelChoiceField(
        queryset=User.objects.filter(is_doctor=True),
        widget=forms.Select(attrs={'class': 'form-input', 'id': 'doctor-select'})
    )

    class Meta:
        model = Appointment
        fields = ['doctor', 'date', 'time_slot', 'priority', 'symptoms', 'notes']
        widgets = {
            'date': forms.DateInput(attrs={
                'class': 'form-input', 'type': 'date'
            }),
            'time_slot': forms.Select(attrs={'class': 'form-input'}),
            'priority': forms.Select(attrs={'class': 'form-input'}),
            'symptoms': forms.Textarea(attrs={
                'class': 'form-input', 'rows': 4,
                'placeholder': 'Describe your symptoms in detail...'
            }),
            'notes': forms.Textarea(attrs={
                'class': 'form-input', 'rows': 3,
                'placeholder': 'Any additional information...'
            }),
        }


class AppointmentStatusForm(forms.Form):
    """Form for doctors to update appointment status."""
    STATUS_CHOICES = [
        ('confirmed', 'Confirm'),
        ('completed', 'Complete'),
        ('cancelled', 'Cancel'),
        ('no_show', 'No Show'),
    ]
    status = forms.ChoiceField(choices=STATUS_CHOICES,
                                widget=forms.Select(attrs={'class': 'form-input'}))
    diagnosis = forms.CharField(required=False,
                                 widget=forms.Textarea(attrs={
                                     'class': 'form-input', 'rows': 3,
                                     'placeholder': 'Diagnosis notes...'
                                 }))


class PrescriptionForm(forms.ModelForm):
    """Form for doctors to write prescriptions."""
    class Meta:
        model = Prescription
        fields = ['medications', 'instructions', 'follow_up_date']
        widgets = {
            'medications': forms.Textarea(attrs={
                'class': 'form-input', 'rows': 5,
                'placeholder': 'Medication 1: Dosage, Frequency\nMedication 2: ...'
            }),
            'instructions': forms.Textarea(attrs={
                'class': 'form-input', 'rows': 3,
                'placeholder': 'Special instructions for the patient...'
            }),
            'follow_up_date': forms.DateInput(attrs={
                'class': 'form-input', 'type': 'date'
            }),
        }


class MedicalRecordForm(forms.ModelForm):
    """Form for doctors to add medical records."""
    class Meta:
        model = MedicalRecord
        fields = ['title', 'description', 'record_type', 'attachment']
        widgets = {
            'title': forms.TextInput(attrs={
                'class': 'form-input', 'placeholder': 'Record title'
            }),
            'description': forms.Textarea(attrs={
                'class': 'form-input', 'rows': 4
            }),
            'record_type': forms.Select(attrs={'class': 'form-input'}),
            'attachment': forms.FileInput(attrs={'class': 'form-input'}),
        }
