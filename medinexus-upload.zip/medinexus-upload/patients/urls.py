from django.urls import path
from . import views

urlpatterns = [
    # Patient views
    path('dashboard/', views.patient_dashboard, name='patient_dashboard'),
    path('book/', views.book_appointment, name='book_appointment'),
    path('appointments/', views.my_appointments, name='my_appointments'),
    path('appointment/<int:pk>/', views.appointment_detail, name='appointment_detail'),
    path('appointment/<int:pk>/cancel/', views.cancel_appointment, name='cancel_appointment'),
    path('prescriptions/', views.my_prescriptions, name='my_prescriptions'),
    path('medical-records/', views.my_medical_records, name='my_medical_records'),
    # Doctor appointment management
    path('manage/', views.manage_appointments, name='manage_appointments'),
    path('manage/<int:pk>/update/', views.update_appointment, name='update_appointment'),
    path('manage/<int:appointment_id>/prescription/', views.write_prescription, name='write_prescription'),
    path('manage/<int:appointment_id>/record/', views.add_medical_record, name='add_medical_record'),
    # API
    path('api/doctors/', views.get_doctors_by_specialty, name='api_doctors_by_specialty'),
]
