from django.contrib import admin
from .models import Appointment, Prescription, MedicalRecord, TimeSlot

@admin.register(TimeSlot)
class TimeSlotAdmin(admin.ModelAdmin):
    list_display = ['time', 'period']

@admin.register(Appointment)
class AppointmentAdmin(admin.ModelAdmin):
    list_display = ['patient', 'doctor', 'date', 'time_slot', 'status', 'priority', 'created_at']
    list_filter = ['status', 'priority', 'date']
    search_fields = ['patient__username', 'doctor__username']

@admin.register(Prescription)
class PrescriptionAdmin(admin.ModelAdmin):
    list_display = ['patient', 'doctor', 'appointment', 'created_at']

@admin.register(MedicalRecord)
class MedicalRecordAdmin(admin.ModelAdmin):
    list_display = ['title', 'patient', 'doctor', 'record_type', 'created_at']
    list_filter = ['record_type']
