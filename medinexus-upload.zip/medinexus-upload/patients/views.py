from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.http import JsonResponse
from django.db.models import Count, Q
from django.utils import timezone
from datetime import timedelta
from .models import Appointment, Prescription, MedicalRecord, TimeSlot
from .forms import (AppointmentBookingForm, AppointmentStatusForm,
                    PrescriptionForm, MedicalRecordForm)
from users.models import User, DoctorProfile, Notification


def patient_required(view_func):
    def wrapper(request, *args, **kwargs):
        if not request.user.is_authenticated or not request.user.is_patient:
            messages.error(request, 'Access denied. Patient account required.')
            return redirect('login')
        return view_func(request, *args, **kwargs)
    return wrapper


def doctor_required(view_func):
    def wrapper(request, *args, **kwargs):
        if not request.user.is_authenticated or not request.user.is_doctor:
            messages.error(request, 'Access denied. Doctor account required.')
            return redirect('login')
        return view_func(request, *args, **kwargs)
    return wrapper


# === Patient Views ===

@login_required
@patient_required
def patient_dashboard(request):
    """Patient's main dashboard."""
    user = request.user
    today = timezone.now().date()

    appointments = Appointment.objects.filter(patient=user)
    upcoming = appointments.filter(
        date__gte=today, status__in=['pending', 'confirmed']
    ).select_related('doctor', 'time_slot').order_by('date')[:5]

    past = appointments.filter(
        Q(date__lt=today) | Q(status__in=['completed', 'cancelled'])
    ).select_related('doctor', 'time_slot').order_by('-date')[:5]

    prescriptions = Prescription.objects.filter(patient=user).order_by('-created_at')[:5]

    # Payment stats
    from payments.models import Payment
    from django.db.models import Sum
    total_paid = Payment.objects.filter(
        patient=user, status='completed'
    ).aggregate(total=Sum('total_amount'))['total'] or 0

    stats = {
        'total_appointments': appointments.count(),
        'upcoming': upcoming.count(),
        'completed': appointments.filter(status='completed').count(),
        'prescriptions': Prescription.objects.filter(patient=user).count(),
        'total_paid': total_paid,
    }

    context = {
        'upcoming_appointments': upcoming,
        'past_appointments': past,
        'prescriptions': prescriptions,
        'stats': stats,
    }
    return render(request, 'patients/dashboard.html', context)


@login_required
@patient_required
def book_appointment(request):
    """Book a new appointment."""
    if request.method == 'POST':
        form = AppointmentBookingForm(request.POST)
        if form.is_valid():
            appointment = form.save(commit=False)
            appointment.patient = request.user
            appointment.save()

            # Notify doctor
            Notification.objects.create(
                user=appointment.doctor,
                notification_type='appointment',
                title='New appointment request',
                message=f'{request.user.full_name} has requested an appointment on {appointment.date}',
                link='/doctors/dashboard/'
            )

            messages.success(request, 'Appointment booked successfully! Awaiting confirmation.')
            return redirect('patient_dashboard')
    else:
        form = AppointmentBookingForm()

    doctors = DoctorProfile.objects.select_related('user', 'specialty').all()
    time_slots = TimeSlot.objects.all()

    context = {
        'form': form,
        'doctors': doctors,
        'time_slots': time_slots,
    }
    return render(request, 'patients/book_appointment.html', context)


@login_required
@patient_required
def my_appointments(request):
    """View all patient appointments with filters."""
    appointments = Appointment.objects.filter(
        patient=request.user
    ).select_related('doctor', 'time_slot').order_by('-date')

    status_filter = request.GET.get('status', '')
    if status_filter:
        appointments = appointments.filter(status=status_filter)

    context = {
        'appointments': appointments,
        'status_filter': status_filter,
    }
    return render(request, 'patients/my_appointments.html', context)


@login_required
@patient_required
def appointment_detail(request, pk):
    """View appointment details."""
    appointment = get_object_or_404(
        Appointment, pk=pk, patient=request.user
    )
    prescription = getattr(appointment, 'prescription', None)
    context = {
        'appointment': appointment,
        'prescription': prescription,
    }
    return render(request, 'patients/appointment_detail.html', context)


@login_required
@patient_required
def cancel_appointment(request, pk):
    """Cancel an appointment."""
    appointment = get_object_or_404(Appointment, pk=pk, patient=request.user)
    if appointment.status in ['pending', 'confirmed']:
        appointment.status = 'cancelled'
        appointment.save()
        Notification.objects.create(
            user=appointment.doctor,
            notification_type='appointment',
            title='Appointment cancelled',
            message=f'{request.user.full_name} cancelled their appointment on {appointment.date}',
            link='/doctors/dashboard/'
        )
        messages.success(request, 'Appointment cancelled.')
    else:
        messages.error(request, 'Cannot cancel this appointment.')
    return redirect('my_appointments')


@login_required
@patient_required
def my_prescriptions(request):
    """View all prescriptions."""
    prescriptions = Prescription.objects.filter(
        patient=request.user
    ).select_related('doctor', 'appointment').order_by('-created_at')
    return render(request, 'patients/my_prescriptions.html', {
        'prescriptions': prescriptions
    })


@login_required
@patient_required
def my_medical_records(request):
    """View medical records."""
    records = MedicalRecord.objects.filter(
        patient=request.user
    ).select_related('doctor').order_by('-created_at')
    return render(request, 'patients/medical_records.html', {
        'records': records
    })


# === Doctor Appointment Management ===

@login_required
@doctor_required
def manage_appointments(request):
    """Doctor manages their appointments."""
    appointments = Appointment.objects.filter(
        doctor=request.user
    ).select_related('patient', 'time_slot').order_by('-date')

    status_filter = request.GET.get('status', '')
    if status_filter:
        appointments = appointments.filter(status=status_filter)

    today = timezone.now().date()
    today_appts = appointments.filter(date=today)
    pending = appointments.filter(status='pending')

    context = {
        'appointments': appointments,
        'today_appointments': today_appts,
        'pending_appointments': pending,
        'status_filter': status_filter,
    }
    return render(request, 'doctors/manage_appointments.html', context)


@login_required
@doctor_required
def update_appointment(request, pk):
    """Doctor updates appointment status."""
    appointment = get_object_or_404(Appointment, pk=pk, doctor=request.user)

    if request.method == 'POST':
        form = AppointmentStatusForm(request.POST)
        if form.is_valid():
            appointment.status = form.cleaned_data['status']
            if form.cleaned_data.get('diagnosis'):
                appointment.diagnosis = form.cleaned_data['diagnosis']
            appointment.save()

            Notification.objects.create(
                user=appointment.patient,
                notification_type='appointment',
                title=f'Appointment {appointment.status}',
                message=f'Your appointment with Dr. {request.user.full_name} on {appointment.date} has been {appointment.status}.',
                link=f'/patients/appointment/{appointment.pk}/'
            )

            messages.success(request, f'Appointment {appointment.status}.')
            return redirect('manage_appointments')
    else:
        form = AppointmentStatusForm()

    context = {'appointment': appointment, 'form': form}
    return render(request, 'doctors/update_appointment.html', context)


@login_required
@doctor_required
def write_prescription(request, appointment_id):
    """Doctor writes a prescription for an appointment."""
    appointment = get_object_or_404(
        Appointment, pk=appointment_id, doctor=request.user
    )
    existing = getattr(appointment, 'prescription', None)

    if request.method == 'POST':
        form = PrescriptionForm(request.POST, instance=existing)
        if form.is_valid():
            prescription = form.save(commit=False)
            prescription.appointment = appointment
            prescription.doctor = request.user
            prescription.patient = appointment.patient
            prescription.save()

            Notification.objects.create(
                user=appointment.patient,
                notification_type='appointment',
                title='New prescription available',
                message=f'Dr. {request.user.full_name} has written a prescription for your visit on {appointment.date}',
                link=f'/patients/prescriptions/'
            )

            messages.success(request, 'Prescription saved successfully!')
            return redirect('manage_appointments')
    else:
        form = PrescriptionForm(instance=existing)

    context = {'form': form, 'appointment': appointment}
    return render(request, 'doctors/write_prescription.html', context)


@login_required
@doctor_required
def add_medical_record(request, appointment_id):
    """Doctor adds a medical record."""
    appointment = get_object_or_404(
        Appointment, pk=appointment_id, doctor=request.user
    )

    if request.method == 'POST':
        form = MedicalRecordForm(request.POST, request.FILES)
        if form.is_valid():
            record = form.save(commit=False)
            record.patient = appointment.patient
            record.doctor = request.user
            record.appointment = appointment
            record.save()
            messages.success(request, 'Medical record added.')
            return redirect('manage_appointments')
    else:
        form = MedicalRecordForm()

    context = {'form': form, 'appointment': appointment}
    return render(request, 'doctors/add_medical_record.html', context)


# === API-like views for AJAX ===

def get_doctors_by_specialty(request):
    """Return doctors filtered by specialty (AJAX)."""
    specialty_id = request.GET.get('specialty_id')
    if specialty_id:
        doctors = User.objects.filter(
            is_doctor=True,
            doctor_profile__specialty_id=specialty_id
        ).values('id', 'first_name', 'last_name')
    else:
        doctors = User.objects.filter(is_doctor=True).values(
            'id', 'first_name', 'last_name'
        )
    data = [{'id': d['id'], 'name': f"Dr. {d['first_name']} {d['last_name']}"}
            for d in doctors]
    return JsonResponse(data, safe=False)
