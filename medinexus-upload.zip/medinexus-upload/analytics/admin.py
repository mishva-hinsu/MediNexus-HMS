from django.contrib import admin
# Analytics uses other apps' models, no separate admin needed.
