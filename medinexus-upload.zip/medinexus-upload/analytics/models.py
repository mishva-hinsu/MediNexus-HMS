from django.db import models
# Analytics app uses data from other apps' models
# No additional models needed
