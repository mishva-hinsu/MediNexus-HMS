from django.urls import path
from . import views

urlpatterns = [
    path('', views.analytics_dashboard, name='analytics_dashboard'),
    path('patient-history/', views.patient_history, name='patient_history'),
    path('patient-history/<int:patient_id>/', views.patient_history, name='patient_history_detail'),
    path('api/<str:chart_type>/', views.analytics_api, name='analytics_api'),
]
