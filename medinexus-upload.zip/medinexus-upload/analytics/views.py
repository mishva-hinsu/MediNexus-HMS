import json
from decimal import Decimal
from datetime import timedelta
from django.shortcuts import render, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.db.models import Count, Avg, Q, F, Sum, Max
from django.db.models.functions import TruncDate, ExtractWeekDay
from django.utils import timezone
from django.http import JsonResponse
from patients.models import Appointment, Prescription, MedicalRecord
from doctors.models import Blog, DoctorRating, Comment
from users.models import User, DoctorProfile, Specialty
from payments.models import Payment


class DecimalEncoder(json.JSONEncoder):
    """Custom JSON encoder that converts Decimal to float."""
    def default(self, obj):
        if isinstance(obj, Decimal):
            return float(obj)
        return super().default(obj)


def safe_json(data):
    """Serialize data to JSON, safely handling Decimals."""
    return json.dumps(data, cls=DecimalEncoder)


@login_required
def analytics_dashboard(request):
    """Main analytics dashboard with comprehensive hospital data."""
    today = timezone.now().date()
    last_30 = today - timedelta(days=30)

    # === OVERVIEW KPIs ===
    total_doctors = User.objects.filter(is_doctor=True).count()
    total_patients = User.objects.filter(is_patient=True).count()
    total_appointments = Appointment.objects.count()
    total_blogs = Blog.objects.filter(is_published=True).count()

    # Month-over-month appointment growth
    this_month = Appointment.objects.filter(date__month=today.month, date__year=today.year).count()
    prev_month_date = today.replace(day=1) - timedelta(days=1)
    prev_month = Appointment.objects.filter(
        date__month=prev_month_date.month, date__year=prev_month_date.year
    ).count()
    appointment_growth = 0
    if prev_month > 0:
        appointment_growth = round(((this_month - prev_month) / prev_month) * 100, 1)

    # === APPOINTMENT ANALYTICS ===
    status_data = list(
        Appointment.objects.values('status').annotate(count=Count('id')).order_by('status')
    )
    priority_data = list(
        Appointment.objects.values('priority').annotate(count=Count('id')).order_by('priority')
    )

    # Monthly appointment trend (last 12 months)
    monthly_trend = []
    for i in range(11, -1, -1):
        month_start = (today.replace(day=1) - timedelta(days=i * 30)).replace(day=1)
        if month_start.month == 12:
            month_end = month_start.replace(year=month_start.year + 1, month=1)
        else:
            month_end = month_start.replace(month=month_start.month + 1)
        count = Appointment.objects.filter(date__gte=month_start, date__lt=month_end).count()
        monthly_trend.append({'month': month_start.strftime('%b %Y'), 'count': count})

    # Daily trend (last 30 days)
    daily_trend = []
    for i in range(29, -1, -1):
        day = today - timedelta(days=i)
        count = Appointment.objects.filter(date=day).count()
        daily_trend.append({'date': day.strftime('%d %b'), 'count': count})

    # Day-of-week distribution
    dow_labels = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat']
    dow_data = [0] * 7
    for item in Appointment.objects.annotate(dow=ExtractWeekDay('date')).values('dow').annotate(count=Count('id')):
        dow_data[item['dow'] - 1] = item['count']

    # === SPECIALTY ANALYTICS (Decimal-safe) ===
    specialty_stats = []
    for item in DoctorProfile.objects.filter(specialty__isnull=False).values('specialty__name').annotate(
        doctor_count=Count('id'), avg_rating=Avg('rating'), total_appointments=Count('user__doctor_appointments')
    ).order_by('-total_appointments'):
        specialty_stats.append({
            'specialty__name': item['specialty__name'],
            'doctor_count': item['doctor_count'],
            'avg_rating': float(item['avg_rating']) if item['avg_rating'] else 0.0,
            'total_appointments': item['total_appointments'],
        })

    # Specialty demand pie
    specialty_demand = list(
        Appointment.objects.filter(doctor__doctor_profile__specialty__isnull=False)
        .values(name=F('doctor__doctor_profile__specialty__name'))
        .annotate(count=Count('id')).order_by('-count')
    )

    # === DOCTOR PERFORMANCE ===
    top_doctors = list(
        DoctorProfile.objects.select_related('user', 'specialty')
        .annotate(
            appt_count=Count('user__doctor_appointments'),
            completed_count=Count('user__doctor_appointments', filter=Q(user__doctor_appointments__status='completed')),
        ).order_by('-appt_count')[:10]
    )

    # === BLOG ANALYTICS ===
    blog_stats = {
        'total': Blog.objects.count(),
        'published': Blog.objects.filter(is_published=True).count(),
        'drafts': Blog.objects.filter(is_published=False).count(),
        'total_views': Blog.objects.aggregate(s=Sum('views_count'))['s'] or 0,
        'total_comments': Comment.objects.count(),
    }
    top_blogs = list(
        Blog.objects.filter(is_published=True).annotate(comment_cnt=Count('comments'))
        .order_by('-views_count')[:5].values('title', 'views_count', 'comment_cnt', 'author__first_name', 'author__last_name')
    )
    category_stats = list(
        Blog.objects.filter(is_published=True).values('category__name').annotate(count=Count('id')).order_by('-count')
    )

    # === PATIENT ANALYTICS ===
    patient_stats = {
        'total': total_patients,
        'new_last_30': User.objects.filter(is_patient=True, date_joined__date__gte=last_30).count(),
        'with_appointments': Appointment.objects.values('patient').distinct().count(),
        'avg_appointments': 0,
    }
    if patient_stats['with_appointments'] > 0:
        patient_stats['avg_appointments'] = round(total_appointments / patient_stats['with_appointments'], 1)

    # Patient growth over time
    patient_growth = []
    for i in range(11, -1, -1):
        month_start = (today.replace(day=1) - timedelta(days=i * 30)).replace(day=1)
        count = User.objects.filter(is_patient=True, date_joined__date__lte=month_start).count()
        patient_growth.append({'month': month_start.strftime('%b %Y'), 'count': count})

    # === RATING ANALYTICS (Decimal-safe) ===
    rating_distribution = [0] * 5
    for item in DoctorRating.objects.values('rating').annotate(count=Count('id')):
        rating_distribution[item['rating'] - 1] = item['count']

    avg_raw = DoctorRating.objects.aggregate(avg=Avg('rating'))['avg']
    avg_platform_rating = round(float(avg_raw), 1) if avg_raw is not None else 0.0

    # Completion / cancellation rates
    completed = Appointment.objects.filter(status='completed').count()
    completion_rate = round((completed / total_appointments * 100), 1) if total_appointments > 0 else 0
    cancelled = Appointment.objects.filter(status='cancelled').count()
    cancel_rate = round((cancelled / total_appointments * 100), 1) if total_appointments > 0 else 0

    context = {
        'total_doctors': total_doctors,
        'total_patients': total_patients,
        'total_appointments': total_appointments,
        'total_blogs': total_blogs,
        'appointment_growth': appointment_growth,
        'completion_rate': completion_rate,
        'cancel_rate': cancel_rate,
        'avg_platform_rating': avg_platform_rating,
        # All chart data uses safe_json
        'status_data': safe_json(status_data),
        'priority_data': safe_json(priority_data),
        'monthly_trend': safe_json(monthly_trend),
        'daily_trend': safe_json(daily_trend),
        'dow_labels': safe_json(dow_labels),
        'dow_data': safe_json(dow_data),
        'specialty_stats': safe_json(specialty_stats),
        'category_stats': safe_json(category_stats),
        'rating_distribution': safe_json(rating_distribution),
        'top_blogs': safe_json(top_blogs),
        'patient_growth': safe_json(patient_growth),
        'specialty_demand': safe_json(specialty_demand),
        # Objects
        'top_doctors': top_doctors,
        'blog_stats': blog_stats,
        'patient_stats': patient_stats,
    }
    return render(request, 'analytics/dashboard.html', context)


# =====================================================================
#  PATIENT HISTORY — visual timeline + analytics
# =====================================================================

@login_required
def patient_history(request, patient_id=None):
    """Patient history analytics with visual timeline and charts."""
    user = request.user
    today = timezone.now().date()

    # Determine whose history to show
    if patient_id and user.is_doctor:
        patient = get_object_or_404(User, pk=patient_id, is_patient=True)
    elif user.is_patient:
        patient = user
    else:
        # Doctor: show a list of their patients to pick from
        patients = (
            User.objects.filter(is_patient=True, patient_appointments__doctor=user)
            .distinct()
            .annotate(
                appt_count=Count('patient_appointments'),
                last_visit=Max('patient_appointments__date'),
            )
            .order_by('-last_visit')
        )
        return render(request, 'analytics/patient_select.html', {'patients': patients})

    # === Gather patient data ===
    appointments = Appointment.objects.filter(patient=patient).select_related('doctor', 'time_slot').order_by('-date')
    prescriptions = Prescription.objects.filter(patient=patient).select_related('doctor', 'appointment').order_by('-created_at')
    medical_records = MedicalRecord.objects.filter(patient=patient).select_related('doctor').order_by('-created_at')

    total_appts = appointments.count()
    completed_appts = appointments.filter(status='completed').count()
    cancelled_appts = appointments.filter(status='cancelled').count()
    total_prescriptions = prescriptions.count()
    total_records = medical_records.count()
    doctors_visited = appointments.values('doctor').distinct().count()

    # --- Build visual timeline ---
    timeline_events = []
    status_colors = {
        'completed': '#2F9E44', 'confirmed': '#1C7ED6',
        'pending': '#F08C00', 'cancelled': '#E03131', 'no_show': '#868E96',
    }
    for apt in appointments[:30]:
        timeline_events.append({
            'date': apt.date.strftime('%Y-%m-%d'),
            'date_display': apt.date.strftime('%b %d, %Y'),
            'type': 'appointment',
            'icon': 'fa-calendar-check',
            'color': status_colors.get(apt.status, '#868E96'),
            'title': f"Appointment with Dr. {apt.doctor.full_name}",
            'detail': f"Status: {apt.get_status_display()} | {apt.time_slot.time if apt.time_slot else 'N/A'}",
            'extra': (apt.symptoms[:80] + '...') if apt.symptoms and len(apt.symptoms) > 80 else (apt.symptoms or ''),
            'status': apt.status,
        })
    for rx in prescriptions[:20]:
        timeline_events.append({
            'date': rx.created_at.strftime('%Y-%m-%d'),
            'date_display': rx.created_at.strftime('%b %d, %Y'),
            'type': 'prescription',
            'icon': 'fa-prescription',
            'color': '#12B886',
            'title': f"Prescription by Dr. {rx.doctor.full_name}",
            'detail': rx.medications[:100] + ('...' if len(rx.medications) > 100 else ''),
            'extra': f"Follow-up: {rx.follow_up_date.strftime('%b %d, %Y')}" if rx.follow_up_date else '',
            'status': 'prescription',
        })
    for rec in medical_records[:20]:
        timeline_events.append({
            'date': rec.created_at.strftime('%Y-%m-%d'),
            'date_display': rec.created_at.strftime('%b %d, %Y'),
            'type': 'record',
            'icon': 'fa-file-medical',
            'color': '#7048E8',
            'title': rec.title,
            'detail': f"Type: {rec.get_record_type_display()} | Dr. {rec.doctor.full_name}",
            'extra': (rec.description[:80] + '...') if len(rec.description) > 80 else rec.description,
            'status': 'record',
        })
    timeline_events.sort(key=lambda x: x['date'], reverse=True)

    # --- Chart: appointments per month ---
    appt_monthly = []
    for i in range(11, -1, -1):
        ms = (today.replace(day=1) - timedelta(days=i * 30)).replace(day=1)
        me = ms.replace(year=ms.year + 1, month=1) if ms.month == 12 else ms.replace(month=ms.month + 1)
        appt_monthly.append({'month': ms.strftime('%b %Y'), 'count': appointments.filter(date__gte=ms, date__lt=me).count()})

    # --- Chart: status breakdown ---
    status_breakdown = list(appointments.values('status').annotate(count=Count('id')).order_by('status'))

    # --- Chart: doctors visited ---
    doctor_visits = []
    for d in appointments.values(name=F('doctor__first_name'), lname=F('doctor__last_name')).annotate(count=Count('id')).order_by('-count')[:8]:
        doctor_visits.append({'doctor_name': f"Dr. {d['name']} {d['lname']}", 'count': d['count']})

    # --- Chart: specialty breakdown ---
    specialty_breakdown = list(
        appointments.filter(doctor__doctor_profile__specialty__isnull=False)
        .values(spec_name=F('doctor__doctor_profile__specialty__name'))
        .annotate(count=Count('id')).order_by('-count')
    )

    try:
        patient_profile = patient.patient_profile
    except Exception:
        patient_profile = None

    context = {
        'patient': patient,
        'patient_profile': patient_profile,
        'appointments': appointments[:20],
        'prescriptions': prescriptions[:10],
        'medical_records': medical_records[:10],
        'total_appts': total_appts,
        'completed_appts': completed_appts,
        'cancelled_appts': cancelled_appts,
        'total_prescriptions': total_prescriptions,
        'total_records': total_records,
        'doctors_visited': doctors_visited,
        'timeline_events': timeline_events[:30],
        'appt_monthly': safe_json(appt_monthly),
        'status_breakdown': safe_json(status_breakdown),
        'doctor_visits': safe_json(doctor_visits),
        'specialty_breakdown': safe_json(specialty_breakdown),
        'is_own_history': (patient == user),
    }
    return render(request, 'analytics/patient_history.html', context)


@login_required
def analytics_api(request, chart_type):
    """API endpoint for dynamic chart data."""
    today = timezone.now().date()
    if chart_type == 'appointments_by_day':
        days = int(request.GET.get('days', 30))
        data = [{'date': (today - timedelta(days=i)).strftime('%Y-%m-%d'),
                 'count': Appointment.objects.filter(date=today - timedelta(days=i)).count()}
                for i in range(days - 1, -1, -1)]
        return JsonResponse(data, safe=False)
    return JsonResponse({'error': 'Invalid chart type'}, status=400)
