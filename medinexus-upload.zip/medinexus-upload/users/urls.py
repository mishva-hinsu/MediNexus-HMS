from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),
    path('users/register/patient/', views.register_patient, name='register_patient'),
    path('users/register/doctor/', views.register_doctor, name='register_doctor'),
    path('users/login/', views.login_view, name='login'),
    path('users/logout/', views.logout_view, name='logout'),
    path('users/profile/', views.profile_view, name='profile'),
    path('users/notifications/', views.notifications_view, name='notifications'),
    path('users/notifications/<int:pk>/read/', views.mark_notification_read, name='mark_notification_read'),
    path('users/notifications/read-all/', views.mark_all_read, name='mark_all_read'),
    path('doctors/list/', views.doctor_list, name='doctor_list'),
    path('doctors/profile/<int:pk>/', views.doctor_detail, name='doctor_detail'),
]
