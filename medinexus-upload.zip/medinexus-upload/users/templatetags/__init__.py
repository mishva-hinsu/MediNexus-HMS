from django import template

register = template.Library()

@register.simple_tag(takes_context=True)
def unread_notifications_count(context):
    request = context.get('request')
    if request and hasattr(request, 'user') and request.user.is_authenticated:
        return request.user.notifications.filter(is_read=False).count()
    return 0

@register.filter
def star_range(value):
    """Return range for star rating display."""
    try:
        return range(int(float(value)))
    except (ValueError, TypeError):
        return range(0)

@register.filter
def empty_star_range(value):
    """Return range for empty stars."""
    try:
        return range(5 - int(float(value)))
    except (ValueError, TypeError):
        return range(5)
