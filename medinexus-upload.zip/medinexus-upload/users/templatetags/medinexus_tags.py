from django import template
from users.models import Notification

register = template.Library()

@register.simple_tag(takes_context=True)
def unread_count(context):
    request = context.get('request')
    if request and hasattr(request, 'user') and request.user.is_authenticated:
        return request.user.notifications.filter(is_read=False).count()
    return 0

@register.filter
def star_range(value):
    try:
        return range(int(float(value)))
    except (ValueError, TypeError):
        return range(0)

@register.filter
def empty_star_range(value):
    try:
        return range(5 - int(float(value)))
    except (ValueError, TypeError):
        return range(5)

@register.filter
def multiply(value, arg):
    try:
        return float(value) * float(arg)
    except (ValueError, TypeError):
        return 0

@register.filter
def percentage(value, total):
    try:
        if float(total) == 0:
            return 0
        return round((float(value) / float(total)) * 100, 1)
    except (ValueError, TypeError):
        return 0
