from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import login, logout, authenticate
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.db.models import Count, Avg, Q
from .models import User, DoctorProfile, PatientProfile, Notification, Specialty
from .forms import (PatientRegistrationForm, DoctorRegistrationForm,
                    LoginForm, UserUpdateForm, DoctorProfileForm,
                    PatientProfileForm)
from patients.models import Appointment


def home(request):
    """Landing page with hospital overview and stats."""
    doctors = DoctorProfile.objects.select_related('user', 'specialty').all()[:6]
    specialties = Specialty.objects.annotate(
        doctor_count=Count('doctorprofile')
    )
    stats = {
        'doctors': User.objects.filter(is_doctor=True).count(),
        'patients': User.objects.filter(is_patient=True).count(),
        'appointments': Appointment.objects.count(),
        'specialties': Specialty.objects.count(),
    }
    context = {
        'doctors': doctors,
        'specialties': specialties,
        'stats': stats,
    }
    return render(request, 'base/home.html', context)


def register_patient(request):
    """Patient registration view."""
    if request.user.is_authenticated:
        return redirect('home')
    if request.method == 'POST':
        form = PatientRegistrationForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            messages.success(request, 'Welcome to MediNexus! Your patient account has been created.')
            Notification.objects.create(
                user=user,
                notification_type='system',
                title='Welcome to MediNexus!',
                message='Your patient account is ready. Start by booking your first appointment.',
                link='/patients/book/'
            )
            return redirect('patient_dashboard')
    else:
        form = PatientRegistrationForm()
    return render(request, 'users/register.html', {
        'form': form, 'user_type': 'patient'
    })


def register_doctor(request):
    """Doctor registration view."""
    if request.user.is_authenticated:
        return redirect('home')
    if request.method == 'POST':
        form = DoctorRegistrationForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            messages.success(request, 'Welcome to MediNexus! Your doctor account has been created.')
            Notification.objects.create(
                user=user,
                notification_type='system',
                title='Welcome to MediNexus!',
                message='Your doctor account is ready. Complete your profile to start receiving appointments.',
                link='/users/profile/'
            )
            return redirect('doctor_dashboard')
    else:
        form = DoctorRegistrationForm()
    return render(request, 'users/register.html', {
        'form': form, 'user_type': 'doctor'
    })


def login_view(request):
    """Custom login view."""
    if request.user.is_authenticated:
        return redirect('home')
    if request.method == 'POST':
        form = LoginForm(request, data=request.POST)
        if form.is_valid():
            user = form.get_user()
            login(request, user)
            messages.success(request, f'Welcome back, {user.full_name}!')
            if user.is_doctor:
                return redirect('doctor_dashboard')
            elif user.is_patient:
                return redirect('patient_dashboard')
            return redirect('home')
    else:
        form = LoginForm()
    return render(request, 'users/login.html', {'form': form})


def logout_view(request):
    """Logout view."""
    logout(request)
    messages.info(request, 'You have been logged out successfully.')
    return redirect('home')


@login_required
def profile_view(request):
    """User profile view and edit."""
    user = request.user
    user_form = UserUpdateForm(instance=user)
    profile_form = None

    if user.is_doctor:
        profile_form = DoctorProfileForm(instance=user.doctor_profile)
    elif user.is_patient:
        profile_form = PatientProfileForm(instance=user.patient_profile)

    if request.method == 'POST':
        user_form = UserUpdateForm(request.POST, request.FILES, instance=user)
        if user.is_doctor:
            profile_form = DoctorProfileForm(request.POST,
                                              instance=user.doctor_profile)
        elif user.is_patient:
            profile_form = PatientProfileForm(request.POST,
                                               instance=user.patient_profile)

        forms_valid = user_form.is_valid()
        if profile_form:
            forms_valid = forms_valid and profile_form.is_valid()

        if forms_valid:
            user_form.save()
            if profile_form:
                profile_form.save()
            messages.success(request, 'Profile updated successfully!')
            return redirect('profile')

    context = {
        'user_form': user_form,
        'profile_form': profile_form,
    }
    return render(request, 'users/profile.html', context)


@login_required
def notifications_view(request):
    """View all notifications."""
    notifications = request.user.notifications.all()[:50]
    return render(request, 'users/notifications.html', {
        'notifications': notifications
    })


@login_required
def mark_notification_read(request, pk):
    """Mark a single notification as read."""
    notif = get_object_or_404(Notification, pk=pk, user=request.user)
    notif.is_read = True
    notif.save()
    if notif.link:
        return redirect(notif.link)
    return redirect('notifications')


@login_required
def mark_all_read(request):
    """Mark all notifications as read."""
    request.user.notifications.filter(is_read=False).update(is_read=True)
    messages.success(request, 'All notifications marked as read.')
    return redirect('notifications')


def doctor_list(request):
    """Public listing of all doctors with filtering."""
    doctors = DoctorProfile.objects.select_related('user', 'specialty').all()
    specialties = Specialty.objects.all()

    # Filters
    specialty_id = request.GET.get('specialty')
    search = request.GET.get('search', '')

    if specialty_id:
        doctors = doctors.filter(specialty_id=specialty_id)
    if search:
        doctors = doctors.filter(
            Q(user__first_name__icontains=search) |
            Q(user__last_name__icontains=search) |
            Q(specialty__name__icontains=search)
        )

    context = {
        'doctors': doctors,
        'specialties': specialties,
        'selected_specialty': specialty_id,
        'search': search,
    }
    return render(request, 'users/doctor_list.html', context)


def doctor_detail(request, pk):
    """Public doctor detail page."""
    profile = get_object_or_404(
        DoctorProfile.objects.select_related('user', 'specialty'), pk=pk
    )
    # Get blogs by this doctor
    from doctors.models import Blog
    blogs = Blog.objects.filter(author=profile.user, is_published=True)[:3]

    context = {
        'doctor': profile,
        'blogs': blogs,
    }
    return render(request, 'users/doctor_detail.html', context)
