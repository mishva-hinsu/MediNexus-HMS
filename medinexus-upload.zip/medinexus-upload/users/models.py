from django.contrib.auth.models import AbstractUser
from django.db import models
from django.utils import timezone


class Specialty(models.Model):
    """Medical specialty for doctors."""
    name = models.CharField(max_length=100)
    description = models.TextField(blank=True)
    icon = models.CharField(max_length=50, default='fa-stethoscope',
                            help_text='FontAwesome icon class')

    class Meta:
        verbose_name_plural = 'Specialties'
        ordering = ['name']

    def __str__(self):
        return self.name


class Address(models.Model):
    """Address model for users."""
    address_line = models.CharField(max_length=255, blank=True)
    city = models.CharField(max_length=100, blank=True)
    state = models.CharField(max_length=100, blank=True)
    postal_code = models.CharField(max_length=20, blank=True)
    country = models.CharField(max_length=100, default='India')

    class Meta:
        verbose_name_plural = 'Addresses'

    def __str__(self):
        parts = [self.address_line, self.city, self.state, self.postal_code]
        return ', '.join(p for p in parts if p)


class User(AbstractUser):
    """Custom user model supporting both patients and doctors."""
    GENDER_CHOICES = [
        ('M', 'Male'),
        ('F', 'Female'),
        ('O', 'Other'),
    ]

    email = models.EmailField(unique=True)
    phone = models.CharField(max_length=20, blank=True)
    birthday = models.DateField(null=True, blank=True)
    gender = models.CharField(max_length=1, choices=GENDER_CHOICES, blank=True)
    avatar = models.ImageField(upload_to='avatars/', blank=True, null=True)
    address = models.ForeignKey(Address, on_delete=models.SET_NULL,
                                null=True, blank=True)
    is_doctor = models.BooleanField(default=False)
    is_patient = models.BooleanField(default=False)
    date_joined = models.DateTimeField(default=timezone.now)

    def __str__(self):
        return f"{self.get_full_name() or self.username}"

    @property
    def full_name(self):
        return self.get_full_name() or self.username

    @property
    def avatar_url(self):
        if self.avatar:
            return self.avatar.url
        return '/static/img/default-avatar.svg'


class DoctorProfile(models.Model):
    """Extended profile for doctors."""
    user = models.OneToOneField(User, on_delete=models.CASCADE,
                                related_name='doctor_profile')
    specialty = models.ForeignKey(Specialty, on_delete=models.SET_NULL,
                                  null=True, blank=True)
    bio = models.TextField(blank=True, default='')
    experience_years = models.PositiveIntegerField(default=0)
    qualification = models.CharField(max_length=255, blank=True)
    consultation_fee = models.DecimalField(max_digits=10, decimal_places=2,
                                           default=500.00)
    available_days = models.CharField(max_length=100,
                                       default='Mon,Tue,Wed,Thu,Fri')
    rating = models.DecimalField(max_digits=3, decimal_places=2, default=0.00)
    total_ratings = models.PositiveIntegerField(default=0)

    def __str__(self):
        specialty = self.specialty.name if self.specialty else 'General'
        return f"Dr. {self.user.full_name} - {specialty}"

    @property
    def avg_rating(self):
        if self.total_ratings == 0:
            return 0
        return round(float(self.rating), 1)


class PatientProfile(models.Model):
    """Extended profile for patients."""
    BLOOD_CHOICES = [
        ('A+', 'A+'), ('A-', 'A-'), ('B+', 'B+'), ('B-', 'B-'),
        ('AB+', 'AB+'), ('AB-', 'AB-'), ('O+', 'O+'), ('O-', 'O-'),
    ]

    user = models.OneToOneField(User, on_delete=models.CASCADE,
                                related_name='patient_profile')
    blood_group = models.CharField(max_length=5, choices=BLOOD_CHOICES,
                                    blank=True)
    allergies = models.TextField(blank=True, default='')
    medical_history = models.TextField(blank=True, default='')
    emergency_contact = models.CharField(max_length=20, blank=True)
    insurance_provider = models.CharField(max_length=100, blank=True)
    insurance_id = models.CharField(max_length=50, blank=True)

    def __str__(self):
        return f"Patient: {self.user.full_name}"


class Notification(models.Model):
    """Notification system for users."""
    TYPES = [
        ('appointment', 'Appointment'),
        ('blog', 'Blog'),
        ('system', 'System'),
        ('rating', 'Rating'),
        ('reminder', 'Reminder'),
    ]

    user = models.ForeignKey(User, on_delete=models.CASCADE,
                             related_name='notifications')
    notification_type = models.CharField(max_length=20, choices=TYPES)
    title = models.CharField(max_length=255)
    message = models.TextField()
    is_read = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)
    link = models.CharField(max_length=255, blank=True)

    class Meta:
        ordering = ['-created_at']

    def __str__(self):
        return f"{self.title} -> {self.user.username}"
