from django.contrib import admin
from django.contrib.auth.admin import UserAdmin as BaseUserAdmin
from .models import User, DoctorProfile, PatientProfile, Specialty, Address, Notification


class DoctorProfileInline(admin.StackedInline):
    model = DoctorProfile
    can_delete = False

class PatientProfileInline(admin.StackedInline):
    model = PatientProfile
    can_delete = False

@admin.register(User)
class UserAdmin(BaseUserAdmin):
    list_display = ['username', 'email', 'first_name', 'last_name', 'is_doctor', 'is_patient']
    list_filter = ['is_doctor', 'is_patient', 'is_staff', 'gender']
    fieldsets = BaseUserAdmin.fieldsets + (
        ('MediNexus Info', {'fields': ('phone', 'birthday', 'gender', 'avatar', 'address', 'is_doctor', 'is_patient')}),
    )

    def get_inlines(self, request, obj=None):
        if obj and obj.is_doctor:
            return [DoctorProfileInline]
        if obj and obj.is_patient:
            return [PatientProfileInline]
        return []

@admin.register(Specialty)
class SpecialtyAdmin(admin.ModelAdmin):
    list_display = ['name', 'icon']

@admin.register(Address)
class AddressAdmin(admin.ModelAdmin):
    list_display = ['address_line', 'city', 'state']

@admin.register(Notification)
class NotificationAdmin(admin.ModelAdmin):
    list_display = ['user', 'title', 'notification_type', 'is_read', 'created_at']
    list_filter = ['notification_type', 'is_read']

admin.site.register(DoctorProfile)
admin.site.register(PatientProfile)
