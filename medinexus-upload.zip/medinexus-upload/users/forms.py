from django import forms
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from .models import User, DoctorProfile, PatientProfile, Address, Specialty


class PatientRegistrationForm(UserCreationForm):
    """Registration form for patients."""
    email = forms.EmailField(
        widget=forms.EmailInput(attrs={
            'class': 'form-input', 'placeholder': 'Email address'
        })
    )
    first_name = forms.CharField(
        max_length=50,
        widget=forms.TextInput(attrs={
            'class': 'form-input', 'placeholder': 'First name'
        })
    )
    last_name = forms.CharField(
        max_length=50,
        widget=forms.TextInput(attrs={
            'class': 'form-input', 'placeholder': 'Last name'
        })
    )
    phone = forms.CharField(
        max_length=20, required=False,
        widget=forms.TextInput(attrs={
            'class': 'form-input', 'placeholder': 'Phone number'
        })
    )

    class Meta:
        model = User
        fields = ['username', 'first_name', 'last_name', 'email',
                  'phone', 'password1', 'password2']
        widgets = {
            'username': forms.TextInput(attrs={
                'class': 'form-input', 'placeholder': 'Username'
            }),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['password1'].widget.attrs.update({
            'class': 'form-input', 'placeholder': 'Password'
        })
        self.fields['password2'].widget.attrs.update({
            'class': 'form-input', 'placeholder': 'Confirm password'
        })

    def save(self, commit=True):
        user = super().save(commit=False)
        user.is_patient = True
        if commit:
            user.save()
        return user


class DoctorRegistrationForm(UserCreationForm):
    """Registration form for doctors."""
    email = forms.EmailField(
        widget=forms.EmailInput(attrs={
            'class': 'form-input', 'placeholder': 'Email address'
        })
    )
    first_name = forms.CharField(
        max_length=50,
        widget=forms.TextInput(attrs={
            'class': 'form-input', 'placeholder': 'First name'
        })
    )
    last_name = forms.CharField(
        max_length=50,
        widget=forms.TextInput(attrs={
            'class': 'form-input', 'placeholder': 'Last name'
        })
    )
    specialty = forms.ModelChoiceField(
        queryset=Specialty.objects.all(),
        required=False,
        widget=forms.Select(attrs={'class': 'form-input'})
    )
    qualification = forms.CharField(
        max_length=255, required=False,
        widget=forms.TextInput(attrs={
            'class': 'form-input', 'placeholder': 'e.g., MBBS, MD'
        })
    )

    class Meta:
        model = User
        fields = ['username', 'first_name', 'last_name', 'email',
                  'password1', 'password2']
        widgets = {
            'username': forms.TextInput(attrs={
                'class': 'form-input', 'placeholder': 'Username'
            }),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['password1'].widget.attrs.update({
            'class': 'form-input', 'placeholder': 'Password'
        })
        self.fields['password2'].widget.attrs.update({
            'class': 'form-input', 'placeholder': 'Confirm password'
        })

    def save(self, commit=True):
        user = super().save(commit=False)
        user.is_doctor = True
        if commit:
            user.save()
            profile = user.doctor_profile
            profile.specialty = self.cleaned_data.get('specialty')
            profile.qualification = self.cleaned_data.get('qualification', '')
            profile.save()
        return user


class LoginForm(AuthenticationForm):
    """Custom styled login form."""
    username = forms.CharField(
        widget=forms.TextInput(attrs={
            'class': 'form-input', 'placeholder': 'Username or Email'
        })
    )
    password = forms.CharField(
        widget=forms.PasswordInput(attrs={
            'class': 'form-input', 'placeholder': 'Password'
        })
    )


class UserUpdateForm(forms.ModelForm):
    """Form for updating user basic info."""
    class Meta:
        model = User
        fields = ['first_name', 'last_name', 'email', 'phone',
                  'birthday', 'gender', 'avatar']
        widgets = {
            'first_name': forms.TextInput(attrs={'class': 'form-input'}),
            'last_name': forms.TextInput(attrs={'class': 'form-input'}),
            'email': forms.EmailInput(attrs={'class': 'form-input'}),
            'phone': forms.TextInput(attrs={'class': 'form-input'}),
            'birthday': forms.DateInput(attrs={
                'class': 'form-input', 'type': 'date'
            }),
            'gender': forms.Select(attrs={'class': 'form-input'}),
            'avatar': forms.FileInput(attrs={'class': 'form-input'}),
        }


class DoctorProfileForm(forms.ModelForm):
    """Form for doctor profile editing."""
    class Meta:
        model = DoctorProfile
        fields = ['specialty', 'bio', 'experience_years', 'qualification',
                  'consultation_fee', 'available_days']
        widgets = {
            'specialty': forms.Select(attrs={'class': 'form-input'}),
            'bio': forms.Textarea(attrs={
                'class': 'form-input', 'rows': 4
            }),
            'experience_years': forms.NumberInput(attrs={'class': 'form-input'}),
            'qualification': forms.TextInput(attrs={'class': 'form-input'}),
            'consultation_fee': forms.NumberInput(attrs={
                'class': 'form-input', 'step': '0.01'
            }),
            'available_days': forms.TextInput(attrs={
                'class': 'form-input',
                'placeholder': 'Mon,Tue,Wed,Thu,Fri'
            }),
        }


class PatientProfileForm(forms.ModelForm):
    """Form for patient profile editing."""
    class Meta:
        model = PatientProfile
        fields = ['blood_group', 'allergies', 'medical_history',
                  'emergency_contact', 'insurance_provider', 'insurance_id']
        widgets = {
            'blood_group': forms.Select(attrs={'class': 'form-input'}),
            'allergies': forms.Textarea(attrs={
                'class': 'form-input', 'rows': 3
            }),
            'medical_history': forms.Textarea(attrs={
                'class': 'form-input', 'rows': 3
            }),
            'emergency_contact': forms.TextInput(attrs={'class': 'form-input'}),
            'insurance_provider': forms.TextInput(attrs={'class': 'form-input'}),
            'insurance_id': forms.TextInput(attrs={'class': 'form-input'}),
        }
