from django.db.models.signals import post_save
from django.dispatch import receiver
from .models import User, DoctorProfile, PatientProfile


@receiver(post_save, sender=User)
def create_user_profile(sender, instance, created, **kwargs):
    """Auto-create doctor/patient profile when user is created."""
    if created:
        if instance.is_doctor:
            DoctorProfile.objects.get_or_create(user=instance)
        elif instance.is_patient:
            PatientProfile.objects.get_or_create(user=instance)


@receiver(post_save, sender=User)
def save_user_profile(sender, instance, **kwargs):
    """Ensure profiles exist when user is saved."""
    if instance.is_doctor and not hasattr(instance, 'doctor_profile'):
        DoctorProfile.objects.get_or_create(user=instance)
    if instance.is_patient and not hasattr(instance, 'patient_profile'):
        PatientProfile.objects.get_or_create(user=instance)
