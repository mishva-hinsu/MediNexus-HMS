"""
Management command to seed the database with realistic demo data.
Generates doctors, patients, appointments, blogs, ratings, prescriptions,
and medical records for a comprehensive analytics dashboard.
"""
import random
import uuid
from datetime import timedelta, date
from django.core.management.base import BaseCommand
from django.utils import timezone
from users.models import User, DoctorProfile, PatientProfile, Specialty, Notification
from doctors.models import Blog, Category, Comment, DoctorRating
from patients.models import Appointment, Prescription, MedicalRecord, TimeSlot


class Command(BaseCommand):
    help = 'Seed database with demo data for MediNexus analytics'

    def handle(self, *args, **kwargs):
        self.stdout.write('Seeding MediNexus database...')

        # --- Doctors ---
        doctor_data = [
            ('Ananya', 'Sharma', 'ananya', 1, 'MBBS, MD Cardiology', 12, 1200),
            ('Rajesh', 'Patel', 'rajesh', 2, 'MBBS, MD Dermatology', 8, 800),
            ('Priya', 'Iyer', 'priya', 3, 'MBBS, DM Neurology', 15, 1500),
            ('Vikram', 'Singh', 'vikram', 4, 'MBBS, MS Orthopedics', 10, 900),
            ('Meera', 'Nair', 'meera', 5, 'MBBS, DCH Pediatrics', 7, 700),
            ('Arjun', 'Reddy', 'arjun', 7, 'MBBS, MD Internal Med', 20, 1000),
            ('Kavitha', 'Das', 'kavitha', 6, 'MBBS, MS Ophthalmology', 9, 850),
            ('Siddharth', 'Joshi', 'siddharth', 8, 'BDS, MDS', 6, 600),
            ('Neha', 'Gupta', 'neha', 9, 'MBBS, MD Psychiatry', 11, 1100),
            ('Rohan', 'Mehta', 'rohan', 10, 'MBBS, MS Gynecology', 14, 1300),
        ]

        doctors = []
        for fn, ln, uname, spec_id, qual, exp, fee in doctor_data:
            user, created = User.objects.get_or_create(
                username=uname,
                defaults={
                    'first_name': fn, 'last_name': ln,
                    'email': f'{uname}@medinexus.care',
                    'is_doctor': True,
                }
            )
            if created:
                user.set_password('medinexus123')
                user.save()
            try:
                spec = Specialty.objects.get(pk=spec_id)
            except Specialty.DoesNotExist:
                spec = None
            profile = user.doctor_profile
            profile.specialty = spec
            profile.qualification = qual
            profile.experience_years = exp
            profile.consultation_fee = fee
            profile.bio = f"Dr. {fn} {ln} is a dedicated {qual} specialist with {exp} years of clinical experience."
            profile.save()
            doctors.append(user)
            self.stdout.write(f'  Doctor: Dr. {fn} {ln}')

        # --- Patients ---
        patient_names = [
            ('Amit', 'Kumar'), ('Sunita', 'Verma'), ('Ravi', 'Sharma'),
            ('Pooja', 'Agarwal'), ('Deepak', 'Mishra'), ('Anjali', 'Gupta'),
            ('Manish', 'Tiwari'), ('Sneha', 'Desai'), ('Kiran', 'Bhat'),
            ('Rahul', 'Yadav'), ('Pallavi', 'Jain'), ('Suresh', 'Pandey'),
            ('Nisha', 'Saxena'), ('Arun', 'Chauhan'), ('Divya', 'Kapoor'),
            ('Gaurav', 'Malik'), ('Shruti', 'Bansal'), ('Vikas', 'Sinha'),
            ('Rekha', 'Dubey'), ('Aman', 'Thakur'),
        ]

        blood_groups = ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-']
        patients = []
        for i, (fn, ln) in enumerate(patient_names):
            uname = f'patient_{fn.lower()}'
            user, created = User.objects.get_or_create(
                username=uname,
                defaults={
                    'first_name': fn, 'last_name': ln,
                    'email': f'{fn.lower()}.{ln.lower()}@email.com',
                    'is_patient': True,
                    'phone': f'+91-98{random.randint(10000000,99999999)}',
                    'gender': random.choice(['M', 'F']),
                    'date_joined': timezone.now() - timedelta(days=random.randint(1, 300)),
                }
            )
            if created:
                user.set_password('medinexus123')
                user.save()
            profile = user.patient_profile
            profile.blood_group = random.choice(blood_groups)
            profile.emergency_contact = f'+91-99{random.randint(10000000,99999999)}'
            profile.save()
            patients.append(user)

        self.stdout.write(f'  Created {len(patients)} patients')

        # --- Appointments ---
        statuses = ['pending', 'confirmed', 'completed', 'cancelled', 'completed', 'completed']
        priorities = ['low', 'normal', 'normal', 'normal', 'high', 'urgent']
        time_slots = list(TimeSlot.objects.all())
        symptom_list = [
            'Chest pain and shortness of breath',
            'Persistent headache for 3 days',
            'Skin rash on arms and neck',
            'Lower back pain radiating to legs',
            'Fever and cough since a week',
            'Blurred vision in left eye',
            'Toothache and swollen gums',
            'Anxiety and sleep issues',
            'Joint stiffness in the morning',
            'Stomach pain after meals',
            'Difficulty breathing during exercise',
            'Recurring migraines with aura',
            'Child has high fever and vomiting',
            'Numbness in hands and feet',
            'Irregular menstrual cycle',
        ]

        today = timezone.now().date()
        appointments = []
        for i in range(150):
            doc = random.choice(doctors)
            pat = random.choice(patients)
            apt_date = today - timedelta(days=random.randint(-15, 180))
            status = random.choice(statuses)
            if apt_date > today:
                status = random.choice(['pending', 'confirmed'])

            apt = Appointment.objects.create(
                patient=pat,
                doctor=doc,
                date=apt_date,
                time_slot=random.choice(time_slots) if time_slots else None,
                status=status,
                priority=random.choice(priorities),
                symptoms=random.choice(symptom_list),
                diagnosis='Clinical assessment completed.' if status == 'completed' else '',
            )
            appointments.append(apt)

        self.stdout.write(f'  Created {len(appointments)} appointments')

        # --- Prescriptions for completed appointments ---
        medications_list = [
            'Paracetamol 500mg: 1 tablet thrice daily after meals\nAmoxicillin 250mg: 1 capsule twice daily',
            'Metformin 500mg: 1 tablet twice daily\nAspirin 75mg: 1 tablet daily',
            'Ibuprofen 400mg: As needed for pain\nOmeprazole 20mg: 1 capsule before breakfast',
            'Amlodipine 5mg: 1 tablet daily\nAtorvastatin 10mg: 1 tablet at bedtime',
            'Cetirizine 10mg: 1 tablet at night\nCalamine lotion: Apply to affected area',
        ]

        completed = [a for a in appointments if a.status == 'completed']
        rx_count = 0
        for apt in completed[:80]:
            if not hasattr(apt, 'prescription'):
                Prescription.objects.create(
                    appointment=apt,
                    doctor=apt.doctor,
                    patient=apt.patient,
                    medications=random.choice(medications_list),
                    instructions='Take medications as prescribed. Drink plenty of water. Rest well.',
                    follow_up_date=apt.date + timedelta(days=random.randint(7, 30)),
                )
                rx_count += 1

        self.stdout.write(f'  Created {rx_count} prescriptions')

        # --- Medical Records ---
        record_types = ['diagnosis', 'lab_result', 'imaging', 'procedure', 'note']
        record_titles = [
            'Blood Test Report', 'X-Ray Results', 'ECG Report',
            'MRI Scan Report', 'Clinical Assessment', 'Ultrasound Report',
            'Routine Check-up Notes', 'Post-Surgery Follow-up',
        ]
        rec_count = 0
        for apt in completed[:40]:
            MedicalRecord.objects.create(
                patient=apt.patient,
                doctor=apt.doctor,
                appointment=apt,
                title=random.choice(record_titles),
                description='Comprehensive medical examination completed. Results within normal limits. Follow-up recommended as discussed.',
                record_type=random.choice(record_types),
            )
            rec_count += 1

        self.stdout.write(f'  Created {rec_count} medical records')

        # --- Blog Posts ---
        categories = list(Category.objects.all())
        blog_data = [
            ('10 Tips for a Healthy Heart', 'Learn essential habits to keep your cardiovascular system strong and prevent heart disease.'),
            ('Understanding Diabetes: A Complete Guide', 'Everything you need to know about managing and preventing diabetes effectively.'),
            ('The Importance of Mental Health Awareness', 'Breaking the stigma around mental health and understanding when to seek help.'),
            ('Nutrition Guide for Strong Bones', 'Dietary recommendations and lifestyle changes to maintain bone health at every age.'),
            ('Childhood Vaccinations: What Parents Should Know', 'A comprehensive guide to vaccination schedules and their importance.'),
            ('Managing Stress in Modern Life', 'Practical strategies for coping with daily stress and maintaining mental well-being.'),
            ('Skin Care Routine for All Seasons', 'Dermatologist-approved tips for healthy, glowing skin throughout the year.'),
            ('Eye Health: Preventing Digital Strain', 'How to protect your eyes in the digital age with simple daily practices.'),
            ('Common Sports Injuries and Prevention', 'Stay active safely with proper warm-up techniques and injury prevention tips.'),
            ('Sleep Hygiene: The Foundation of Good Health', 'Why quality sleep matters and how to improve your sleep habits.'),
            ('Hypertension: Silent Killer Explained', 'Understanding blood pressure and effective management strategies.'),
            ('Healthy Eating on a Budget', 'Nutritious meal planning that is both affordable and delicious.'),
        ]

        for i, (title, summary) in enumerate(blog_data):
            doc = doctors[i % len(doctors)]
            content = f"""
{summary}

Medical research consistently shows the importance of preventive care and healthy lifestyle choices. Regular check-ups and early detection can significantly improve treatment outcomes.

Key takeaways from recent clinical studies include the importance of consistent physical activity, balanced nutrition, adequate sleep, and stress management. These foundational health practices form the cornerstone of disease prevention.

Always consult with your healthcare provider before making significant changes to your health routine. Personalized medical advice ensures the best outcomes for your individual health situation.

At MediNexus, we believe in empowering patients with accurate, evidence-based medical information. Our team of specialists is dedicated to providing the highest quality healthcare services.
            """.strip()

            blog = Blog.objects.create(
                title=title,
                summary=summary,
                content=content,
                author=doc,
                category=random.choice(categories) if categories else None,
                is_published=True,
                is_featured=(i < 3),
                views_count=random.randint(20, 500),
                created_at=timezone.now() - timedelta(days=random.randint(1, 120)),
            )

            # Add comments
            for _ in range(random.randint(1, 5)):
                Comment.objects.create(
                    blog=blog,
                    user=random.choice(patients),
                    content=random.choice([
                        'Very informative article! Thank you, doctor.',
                        'This helped me understand my condition better.',
                        'Great advice, I will follow these recommendations.',
                        'Can you write more about this topic?',
                        'Sharing this with my family members.',
                    ]),
                )

        self.stdout.write(f'  Created {len(blog_data)} blog posts with comments')

        # --- Doctor Ratings ---
        rating_count = 0
        for doc in doctors:
            raters = random.sample(patients, min(len(patients), random.randint(3, 12)))
            for pat in raters:
                rating_val = random.choices([3, 4, 4, 5, 5, 5], k=1)[0]
                DoctorRating.objects.get_or_create(
                    doctor=doc, patient=pat,
                    defaults={
                        'rating': rating_val,
                        'review': random.choice([
                            'Excellent doctor, very thorough and caring.',
                            'Great experience! Highly recommended.',
                            'Professional and knowledgeable.',
                            'Good consultation, explained everything clearly.',
                            'Very patient and attentive.',
                        ]),
                    }
                )
                rating_count += 1

            # Update doctor profile rating
            from django.db.models import Avg, Count
            stats = DoctorRating.objects.filter(doctor=doc).aggregate(
                avg=Avg('rating'), count=Count('id')
            )
            profile = doc.doctor_profile
            profile.rating = stats['avg'] or 0
            profile.total_ratings = stats['count'] or 0
            profile.save()

        self.stdout.write(f'  Created {rating_count} ratings')

        # --- Payments for completed appointments ---
        from payments.models import Payment
        from decimal import Decimal
        payment_methods = ['razorpay', 'upi', 'card', 'netbanking', 'wallet']
        pay_count = 0
        for apt in completed[:60]:
            if hasattr(apt, 'payment'):
                continue
            try:
                fee = apt.doctor.doctor_profile.consultation_fee
            except Exception:
                fee = Decimal('500.00')
            payment = Payment.objects.create(
                patient=apt.patient,
                doctor=apt.doctor,
                appointment=apt,
                amount=fee,
                gst_amount=Decimal('0.00'),
                total_amount=fee,
                status='completed',
                method=random.choice(payment_methods),
                description=f"Consultation with Dr. {apt.doctor.full_name}",
                paid_at=timezone.now() - timedelta(days=random.randint(0, 150)),
            )
            payment.transaction_id = f"txn_{uuid.uuid4().hex[:16]}"
            payment.save()
            pay_count += 1

        self.stdout.write(f'  Created {pay_count} payments')

        # --- Admin user ---
        if not User.objects.filter(is_superuser=True).exists():
            admin = User.objects.create_superuser(
                username='admin',
                email='admin@medinexus.care',
                password='admin123',
                first_name='Admin',
                last_name='MediNexus'
            )
            self.stdout.write('  Created admin user: admin / admin123')

        self.stdout.write(self.style.SUCCESS(
            '\n✅ MediNexus database seeded successfully!\n'
            '\nLogin Credentials:\n'
            '  Admin:   admin / admin123\n'
            '  Doctors: ananya / medinexus123 (or any doctor username)\n'
            '  Patients: patient_amit / medinexus123 (or any patient username)\n'
        ))
