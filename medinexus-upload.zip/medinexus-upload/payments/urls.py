from django.urls import path
from . import views

urlpatterns = [
    path('checkout/<int:appointment_id>/', views.payment_checkout, name='payment_checkout'),
    path('process/<str:payment_id>/', views.payment_process, name='payment_process'),
    path('success/<str:payment_id>/', views.payment_success, name='payment_success'),
    path('failure/<str:payment_id>/', views.payment_failure, name='payment_failure'),
    path('invoice/<str:payment_id>/', views.payment_invoice, name='payment_invoice'),
    path('history/', views.payment_history, name='payment_history'),
    path('refund/<str:payment_id>/', views.request_refund, name='request_refund'),
]
