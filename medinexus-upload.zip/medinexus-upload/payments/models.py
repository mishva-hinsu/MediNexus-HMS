import uuid
import hashlib
import time
from django.db import models
from django.conf import settings
from django.utils import timezone


class Payment(models.Model):
    """Payment record for appointment consultations."""
    STATUS_CHOICES = [
        ('pending', 'Pending'),
        ('processing', 'Processing'),
        ('completed', 'Completed'),
        ('failed', 'Failed'),
        ('refunded', 'Refunded'),
    ]

    METHOD_CHOICES = [
        ('razorpay', 'Razorpay'),
        ('upi', 'UPI'),
        ('card', 'Credit/Debit Card'),
        ('netbanking', 'Net Banking'),
        ('wallet', 'Wallet'),
    ]

    # Core fields
    payment_id = models.CharField(max_length=50, unique=True, editable=False)
    order_id = models.CharField(max_length=50, unique=True, editable=False)
    patient = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE,
                                 related_name='payments')
    doctor = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE,
                                related_name='received_payments')
    appointment = models.OneToOneField('patients.Appointment', on_delete=models.CASCADE,
                                        related_name='payment', null=True, blank=True)

    # Amount
    amount = models.DecimalField(max_digits=10, decimal_places=2)
    currency = models.CharField(max_length=3, default='INR')
    gst_amount = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    total_amount = models.DecimalField(max_digits=10, decimal_places=2)

    # Payment info
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='pending')
    method = models.CharField(max_length=20, choices=METHOD_CHOICES, default='razorpay')
    transaction_id = models.CharField(max_length=100, blank=True,
                                       help_text='Gateway transaction reference')

    # Invoice
    invoice_number = models.CharField(max_length=20, unique=True, editable=False)
    description = models.CharField(max_length=255, default='Consultation Fee')

    # Timestamps
    created_at = models.DateTimeField(auto_now_add=True)
    paid_at = models.DateTimeField(null=True, blank=True)
    updated_at = models.DateTimeField(auto_now=True)

    # Refund
    refund_reason = models.TextField(blank=True)
    refunded_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        ordering = ['-created_at']

    def __str__(self):
        return f"INV-{self.invoice_number} | ₹{self.total_amount} | {self.get_status_display()}"

    def save(self, *args, **kwargs):
        if not self.payment_id:
            self.payment_id = f"pay_{uuid.uuid4().hex[:16]}"
        if not self.order_id:
            self.order_id = f"order_{uuid.uuid4().hex[:16]}"
        if not self.invoice_number:
            ts = int(time.time() * 1000) % 1000000
            self.invoice_number = f"MNX-{timezone.now().strftime('%Y%m')}-{ts:06d}"
        if not self.gst_amount:
            self.gst_amount = round(self.amount * 0, 2)  # 0% GST for medical
        if not self.total_amount:
            self.total_amount = self.amount + self.gst_amount
        super().save(*args, **kwargs)

    @property
    def status_color(self):
        return {
            'pending': 'warning', 'processing': 'info',
            'completed': 'success', 'failed': 'danger', 'refunded': 'secondary',
        }.get(self.status, 'secondary')

    @property
    def is_paid(self):
        return self.status == 'completed'

    def mark_completed(self, transaction_id='', method='razorpay'):
        """Mark payment as completed."""
        self.status = 'completed'
        self.transaction_id = transaction_id or f"txn_{uuid.uuid4().hex[:12]}"
        self.method = method
        self.paid_at = timezone.now()
        self.save()

    def mark_failed(self):
        self.status = 'failed'
        self.save()

    def process_refund(self, reason=''):
        """Process a refund for this payment."""
        if self.status != 'completed':
            return False
        self.status = 'refunded'
        self.refund_reason = reason
        self.refunded_at = timezone.now()
        self.save()
        return True

    def generate_signature(self):
        """Generate a verification signature (simulates Razorpay signature)."""
        data = f"{self.order_id}|{self.payment_id}|{self.total_amount}"
        return hashlib.sha256(data.encode()).hexdigest()[:32]
