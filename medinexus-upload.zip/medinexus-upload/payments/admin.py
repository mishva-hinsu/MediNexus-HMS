from django.contrib import admin
from .models import Payment


@admin.register(Payment)
class PaymentAdmin(admin.ModelAdmin):
    list_display = ['invoice_number', 'patient', 'doctor', 'total_amount',
                    'status', 'method', 'paid_at', 'created_at']
    list_filter = ['status', 'method', 'currency']
    search_fields = ['payment_id', 'order_id', 'invoice_number',
                     'patient__username', 'doctor__username']
    readonly_fields = ['payment_id', 'order_id', 'invoice_number', 'transaction_id']
    date_hierarchy = 'created_at'
