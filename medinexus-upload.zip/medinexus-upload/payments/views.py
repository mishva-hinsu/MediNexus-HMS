import json
import uuid
import hashlib
from decimal import Decimal
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.http import JsonResponse
from django.utils import timezone
from django.db.models import Sum, Count, Q
from .models import Payment
from patients.models import Appointment
from users.models import User, Notification


def patient_required(view_func):
    def wrapper(request, *args, **kwargs):
        if not request.user.is_authenticated or not request.user.is_patient:
            messages.error(request, 'Access denied. Patient account required.')
            return redirect('login')
        return view_func(request, *args, **kwargs)
    return wrapper


@login_required
@patient_required
def payment_checkout(request, appointment_id):
    """Razorpay-style checkout page for an appointment."""
    appointment = get_object_or_404(
        Appointment, pk=appointment_id, patient=request.user
    )

    # Check if already paid
    if hasattr(appointment, 'payment') and appointment.payment.is_paid:
        messages.info(request, 'This appointment is already paid.')
        return redirect('appointment_detail', pk=appointment.pk)

    # Get doctor's consultation fee
    try:
        fee = appointment.doctor.doctor_profile.consultation_fee
    except Exception:
        fee = Decimal('500.00')

    gst = round(fee * Decimal('0.00'), 2)  # 0% GST for medical services
    total = fee + gst

    # Create or get pending payment
    payment, created = Payment.objects.get_or_create(
        appointment=appointment,
        defaults={
            'patient': request.user,
            'doctor': appointment.doctor,
            'amount': fee,
            'gst_amount': gst,
            'total_amount': total,
            'description': f"Consultation with Dr. {appointment.doctor.full_name}",
        }
    )

    # If payment exists but failed, reset it
    if not created and payment.status == 'failed':
        payment.status = 'pending'
        payment.save()

    context = {
        'appointment': appointment,
        'payment': payment,
        'fee': fee,
        'gst': gst,
        'total': total,
        'doctor': appointment.doctor,
    }
    return render(request, 'payments/checkout.html', context)


@login_required
@patient_required
def payment_process(request, payment_id):
    """Process payment — simulates Razorpay payment gateway callback."""
    payment = get_object_or_404(Payment, payment_id=payment_id, patient=request.user)

    if request.method != 'POST':
        return redirect('payment_checkout', appointment_id=payment.appointment.pk)

    # Get payment method from the form
    method = request.POST.get('payment_method', 'razorpay')
    card_number = request.POST.get('card_number', '')
    upi_id = request.POST.get('upi_id', '')

    # Simulate payment processing
    # In production, this would call Razorpay API:
    # razorpay_client.payment.capture(payment_id, amount)
    payment.status = 'processing'
    payment.save()

    # Simulate gateway verification
    # Real Razorpay would verify signature: 
    # razorpay_client.utility.verify_payment_signature(params_dict)
    transaction_id = f"txn_{uuid.uuid4().hex[:16]}"
    signature = payment.generate_signature()

    # Mark as completed
    payment.mark_completed(transaction_id=transaction_id, method=method)

    # Update appointment status to confirmed after payment
    if payment.appointment:
        apt = payment.appointment
        if apt.status == 'pending':
            apt.status = 'confirmed'
            apt.save()

        # Notify doctor
        Notification.objects.create(
            user=apt.doctor,
            notification_type='appointment',
            title='Payment received — Appointment confirmed',
            message=f'{request.user.full_name} paid ₹{payment.total_amount} for appointment on {apt.date}. Appointment auto-confirmed.',
            link='/patients/manage/'
        )

    # Notify patient
    Notification.objects.create(
        user=request.user,
        notification_type='system',
        title='Payment successful!',
        message=f'Your payment of ₹{payment.total_amount} for Dr. {payment.doctor.full_name} was successful. Invoice: {payment.invoice_number}',
        link=f'/payments/invoice/{payment.payment_id}/'
    )

    return redirect('payment_success', payment_id=payment.payment_id)


@login_required
@patient_required
def payment_success(request, payment_id):
    """Payment success page with receipt details."""
    payment = get_object_or_404(Payment, payment_id=payment_id, patient=request.user)
    context = {'payment': payment}
    return render(request, 'payments/success.html', context)


@login_required
@patient_required
def payment_failure(request, payment_id):
    """Payment failure page."""
    payment = get_object_or_404(Payment, payment_id=payment_id, patient=request.user)
    payment.mark_failed()
    context = {'payment': payment}
    return render(request, 'payments/failure.html', context)


@login_required
def payment_invoice(request, payment_id):
    """View invoice/receipt for a payment."""
    payment = get_object_or_404(Payment, payment_id=payment_id)

    # Allow access for patient, doctor, or admin
    if not (request.user == payment.patient or
            request.user == payment.doctor or
            request.user.is_staff):
        messages.error(request, 'Access denied.')
        return redirect('home')

    context = {'payment': payment}
    return render(request, 'payments/invoice.html', context)


@login_required
def payment_history(request):
    """Payment history for patients (their payments) or doctors (received payments)."""
    user = request.user

    if user.is_patient:
        payments = Payment.objects.filter(patient=user).select_related(
            'doctor', 'appointment'
        )
        total_paid = payments.filter(status='completed').aggregate(
            total=Sum('total_amount'))['total'] or 0
    elif user.is_doctor:
        payments = Payment.objects.filter(doctor=user).select_related(
            'patient', 'appointment'
        )
        total_paid = payments.filter(status='completed').aggregate(
            total=Sum('total_amount'))['total'] or 0
    else:
        payments = Payment.objects.none()
        total_paid = 0

    # Filters
    status_filter = request.GET.get('status', '')
    if status_filter:
        payments = payments.filter(status=status_filter)

    stats = {
        'total_payments': payments.count(),
        'completed': payments.filter(status='completed').count(),
        'pending': payments.filter(status='pending').count(),
        'total_amount': total_paid,
    }

    context = {
        'payments': payments[:50],
        'stats': stats,
        'status_filter': status_filter,
    }
    return render(request, 'payments/history.html', context)


@login_required
@patient_required
def request_refund(request, payment_id):
    """Patient requests a refund."""
    payment = get_object_or_404(
        Payment, payment_id=payment_id, patient=request.user, status='completed'
    )

    if request.method == 'POST':
        reason = request.POST.get('reason', 'Patient requested refund')
        success = payment.process_refund(reason=reason)

        if success:
            # Cancel the appointment too
            if payment.appointment:
                payment.appointment.status = 'cancelled'
                payment.appointment.save()

            Notification.objects.create(
                user=payment.doctor,
                notification_type='system',
                title='Payment refunded',
                message=f'Payment of ₹{payment.total_amount} from {request.user.full_name} has been refunded. Reason: {reason}',
                link='/payments/history/'
            )

            messages.success(request, f'Refund of ₹{payment.total_amount} processed successfully.')
        else:
            messages.error(request, 'Refund could not be processed.')

        return redirect('payment_history')

    context = {'payment': payment}
    return render(request, 'payments/refund.html', context)
