from django import forms
from .models import Blog, Comment, Category, DoctorRating


class BlogForm(forms.ModelForm):
    """Form for creating/editing blog posts."""
    class Meta:
        model = Blog
        fields = ['title', 'summary', 'content', 'category', 'thumbnail',
                  'is_published', 'is_featured']
        widgets = {
            'title': forms.TextInput(attrs={
                'class': 'form-input', 'placeholder': 'Blog title'
            }),
            'summary': forms.Textarea(attrs={
                'class': 'form-input', 'rows': 3,
                'placeholder': 'Brief summary of the article...'
            }),
            'content': forms.Textarea(attrs={
                'class': 'form-input', 'rows': 12,
                'placeholder': 'Write your medical article here...'
            }),
            'category': forms.Select(attrs={'class': 'form-input'}),
            'thumbnail': forms.FileInput(attrs={'class': 'form-input'}),
            'is_published': forms.CheckboxInput(attrs={'class': 'form-checkbox'}),
            'is_featured': forms.CheckboxInput(attrs={'class': 'form-checkbox'}),
        }


class CommentForm(forms.ModelForm):
    """Form for blog comments."""
    class Meta:
        model = Comment
        fields = ['content']
        widgets = {
            'content': forms.Textarea(attrs={
                'class': 'form-input', 'rows': 3,
                'placeholder': 'Write your comment...'
            }),
        }


class RatingForm(forms.ModelForm):
    """Form for rating a doctor."""
    class Meta:
        model = DoctorRating
        fields = ['rating', 'review']
        widgets = {
            'rating': forms.RadioSelect(choices=[(i, str(i)) for i in range(1, 6)]),
            'review': forms.Textarea(attrs={
                'class': 'form-input', 'rows': 3,
                'placeholder': 'Share your experience...'
            }),
        }
