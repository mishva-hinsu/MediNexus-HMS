from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.db.models import Count, Avg, Q, Sum
from django.utils import timezone
from datetime import timedelta
from .models import Blog, Comment, Category, DoctorRating
from .forms import BlogForm, CommentForm, RatingForm
from patients.models import Appointment
from users.models import Notification


def doctor_required(view_func):
    """Decorator to ensure user is a doctor."""
    def wrapper(request, *args, **kwargs):
        if not request.user.is_authenticated or not request.user.is_doctor:
            messages.error(request, 'Access denied. Doctor account required.')
            return redirect('login')
        return view_func(request, *args, **kwargs)
    return wrapper


@login_required
@doctor_required
def doctor_dashboard(request):
    """Doctor's main dashboard with analytics overview."""
    user = request.user
    today = timezone.now().date()
    week_ago = today - timedelta(days=7)
    month_ago = today - timedelta(days=30)

    # Appointments
    appointments = Appointment.objects.filter(doctor=user)
    today_appointments = appointments.filter(date=today, status='confirmed')
    pending_appointments = appointments.filter(status='pending')
    total_patients = appointments.values('patient').distinct().count()

    # Blog stats
    blogs = Blog.objects.filter(author=user)
    total_views = blogs.aggregate(total=Sum('views_count'))['total'] or 0

    # Monthly appointment trend
    monthly_data = []
    for i in range(6, -1, -1):
        d = today - timedelta(days=i * 30)
        d_end = d + timedelta(days=30)
        count = appointments.filter(date__gte=d, date__lt=d_end).count()
        monthly_data.append({
            'month': d.strftime('%b'),
            'count': count
        })

    # Rating
    ratings = DoctorRating.objects.filter(doctor=user)
    avg_rating = ratings.aggregate(avg=Avg('rating'))['avg'] or 0

    # Recent appointments
    recent_appointments = appointments.select_related('patient').order_by('-date')[:5]

    context = {
        'today_appointments': today_appointments,
        'pending_appointments': pending_appointments,
        'total_patients': total_patients,
        'total_blogs': blogs.count(),
        'published_blogs': blogs.filter(is_published=True).count(),
        'total_views': total_views,
        'avg_rating': round(avg_rating, 1),
        'total_ratings': ratings.count(),
        'monthly_data': monthly_data,
        'recent_appointments': recent_appointments,
        'pending_count': pending_appointments.count(),
        'today_count': today_appointments.count(),
    }
    return render(request, 'doctors/dashboard.html', context)


# --- Blog Views ---

def blog_list(request):
    """Public blog listing with search and filter."""
    blogs = Blog.objects.filter(is_published=True).select_related('author', 'category')
    categories = Category.objects.annotate(blog_count=Count('blogs'))

    # Filters
    cat_slug = request.GET.get('category')
    search = request.GET.get('search', '')

    if cat_slug:
        blogs = blogs.filter(category__slug=cat_slug)
    if search:
        blogs = blogs.filter(
            Q(title__icontains=search) |
            Q(summary__icontains=search) |
            Q(content__icontains=search)
        )

    featured = Blog.objects.filter(is_published=True, is_featured=True)[:3]

    context = {
        'blogs': blogs,
        'categories': categories,
        'featured': featured,
        'search': search,
        'selected_category': cat_slug,
    }
    return render(request, 'blog/blog_list.html', context)


def blog_detail(request, slug):
    """Blog detail page with comments."""
    blog = get_object_or_404(Blog, slug=slug)

    # Increment view count
    blog.views_count += 1
    blog.save(update_fields=['views_count'])

    comments = blog.comments.filter(parent=None).select_related('user')
    comment_form = CommentForm()

    if request.method == 'POST' and request.user.is_authenticated:
        comment_form = CommentForm(request.POST)
        if comment_form.is_valid():
            comment = comment_form.save(commit=False)
            comment.blog = blog
            comment.user = request.user
            parent_id = request.POST.get('parent_id')
            if parent_id:
                comment.parent = Comment.objects.get(pk=parent_id)
            comment.save()

            # Notify blog author
            if request.user != blog.author:
                Notification.objects.create(
                    user=blog.author,
                    notification_type='blog',
                    title='New comment on your blog',
                    message=f'{request.user.full_name} commented on "{blog.title}"',
                    link=f'/doctors/blog/{blog.slug}/'
                )

            messages.success(request, 'Comment posted successfully!')
            return redirect('blog_detail', slug=slug)

    related = Blog.objects.filter(
        is_published=True, category=blog.category
    ).exclude(pk=blog.pk)[:3]

    context = {
        'blog': blog,
        'comments': comments,
        'comment_form': comment_form,
        'related_blogs': related,
    }
    return render(request, 'blog/blog_detail.html', context)


@login_required
@doctor_required
def blog_create(request):
    """Create a new blog post."""
    if request.method == 'POST':
        form = BlogForm(request.POST, request.FILES)
        if form.is_valid():
            blog = form.save(commit=False)
            blog.author = request.user
            blog.save()
            status = 'published' if blog.is_published else 'saved as draft'
            messages.success(request, f'Blog {status} successfully!')
            return redirect('doctor_dashboard')
    else:
        form = BlogForm()
    return render(request, 'blog/blog_form.html', {'form': form, 'action': 'Create'})


@login_required
@doctor_required
def blog_edit(request, slug):
    """Edit an existing blog post."""
    blog = get_object_or_404(Blog, slug=slug, author=request.user)
    if request.method == 'POST':
        form = BlogForm(request.POST, request.FILES, instance=blog)
        if form.is_valid():
            form.save()
            messages.success(request, 'Blog updated successfully!')
            return redirect('blog_detail', slug=blog.slug)
    else:
        form = BlogForm(instance=blog)
    return render(request, 'blog/blog_form.html', {'form': form, 'action': 'Edit', 'blog': blog})


@login_required
@doctor_required
def blog_delete(request, slug):
    """Delete a blog post."""
    blog = get_object_or_404(Blog, slug=slug, author=request.user)
    if request.method == 'POST':
        blog.delete()
        messages.success(request, 'Blog deleted successfully.')
        return redirect('doctor_dashboard')
    return render(request, 'blog/blog_confirm_delete.html', {'blog': blog})


@login_required
@doctor_required
def my_blogs(request):
    """List doctor's own blogs (published + drafts)."""
    blogs = Blog.objects.filter(author=request.user)
    published = blogs.filter(is_published=True)
    drafts = blogs.filter(is_published=False)
    context = {
        'published': published,
        'drafts': drafts,
    }
    return render(request, 'blog/my_blogs.html', context)


# --- Rating Views ---

@login_required
def rate_doctor(request, doctor_id):
    """Patient rates a doctor."""
    from users.models import User
    doctor = get_object_or_404(User, pk=doctor_id, is_doctor=True)

    if not request.user.is_patient:
        messages.error(request, 'Only patients can rate doctors.')
        return redirect('doctor_detail', pk=doctor.doctor_profile.pk)

    existing = DoctorRating.objects.filter(doctor=doctor, patient=request.user).first()

    if request.method == 'POST':
        form = RatingForm(request.POST, instance=existing)
        if form.is_valid():
            rating = form.save(commit=False)
            rating.doctor = doctor
            rating.patient = request.user
            rating.save()

            # Update doctor profile rating
            avg = DoctorRating.objects.filter(doctor=doctor).aggregate(
                avg=Avg('rating'), count=Count('id')
            )
            profile = doctor.doctor_profile
            profile.rating = avg['avg'] or 0
            profile.total_ratings = avg['count'] or 0
            profile.save()

            Notification.objects.create(
                user=doctor,
                notification_type='rating',
                title='New rating received',
                message=f'{request.user.full_name} rated you {rating.rating}/5',
                link='/users/profile/'
            )

            messages.success(request, 'Thank you for your rating!')
            return redirect('doctor_detail', pk=doctor.doctor_profile.pk)
    else:
        form = RatingForm(instance=existing)

    context = {'form': form, 'doctor': doctor}
    return render(request, 'doctors/rate_doctor.html', context)
